<?php include_once "../base.php";

$Mem->save($_POST);
