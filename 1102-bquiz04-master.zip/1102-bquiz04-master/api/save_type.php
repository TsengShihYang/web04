<?php include_once "../base.php";
$Type->save($_POST);