<?php include_once "../base.php";

$Mem->save($_POST);

to("../back.php?do=mem");