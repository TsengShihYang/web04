<?php

unset($_SESSION['admin']);
to("index.php");

?>