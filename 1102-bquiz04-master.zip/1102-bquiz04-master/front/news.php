<h1 class="ct">最新消息</h1>
<table class="all">
    <tr class="tt ct">
        <td>標題</td>
    </tr>
    <tr class="pp">
        <td>情人節特惠活動</td>
    </tr>
    <tr class="pp">
        <td>年終特賣會開跑了</td>
    </tr>
</table>