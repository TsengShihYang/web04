// JavaScript Document
function lof(x)
{
	location.href=x
}